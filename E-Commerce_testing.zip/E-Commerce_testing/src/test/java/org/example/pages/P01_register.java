package org.example.pages;

import org.example.stepDefs.Hooks;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.asserts.SoftAssert;


public class P01_register {

    public P01_register()
    {
        PageFactory.initElements(Hooks.driver,this);
    }
    @FindBy(className = "ico-register")
    public WebElement registerLink;

    @FindBy(id = "gender-male")
    public WebElement maleBtn;

    @FindBy(id = "gender-female")
    public WebElement femaleBtn;

    @FindBy(id = "FirstName")
    WebElement firstName;

    @FindBy(id = "LastName")
    WebElement lastName;

    public void registerSteps(String FirstName, String LastName)
    {
        firstName.clear();
        firstName.sendKeys(FirstName);

        lastName.clear();
        lastName.sendKeys(LastName);
    }

    @FindBy(name = "DateOfBirthDay")
    WebElement birthDay;

    @FindBy(name = "DateOfBirthMonth")
    WebElement birthMonth;

    @FindBy(name = "DateOfBirthYear")
    WebElement birthYear;

    public void dateOfBirth(String Day, String Month, String Year) throws InterruptedException {
        Select selectDay = new Select(birthDay);
        selectDay.selectByValue("0");
        Select selectMonth = new Select(birthMonth);
        selectMonth.selectByValue("0");
        Select selectYear = new Select(birthYear);
        selectYear.selectByValue("0");
        Thread.sleep(2000);

        selectDay.selectByValue(Day);
        selectMonth.selectByValue(Month);
        selectYear.selectByValue(Year);
    }

    @FindBy(id="Email")
    WebElement email;

    public void enterEmail(String Email)
    {
        email.clear();
        email.sendKeys(Email);
    }

    @FindBy(id="Password")
    WebElement password;

    @FindBy(id="ConfirmPassword")
    WebElement confirmPassword;

    public void enterPassword(String Password, String ConfirmPassword)
    {
        password.clear();
        password.sendKeys(Password);

        confirmPassword.clear();
        confirmPassword.sendKeys(ConfirmPassword);
    }

    @FindBy(id="register-button")
    public WebElement registerBtn;

    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]")
    WebElement successMsg;

    public void successMsgDisplay()
    {
        SoftAssert soft = new SoftAssert();

        String expectedMsg = "Your registration completed";
        String actualMsg = successMsg.getText();
        soft.assertEquals(actualMsg.contains(expectedMsg),true,"Text");

        String expectedColor = "rgba(76, 177, 124, 1)";
        String actualColor = successMsg.getCssValue("color");
        soft.assertEquals(actualColor.contains(expectedColor),true,"Color");

        soft.assertAll();
    }

    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div/div/div[2]/div[2]/a")
    public WebElement continueBtn;


}
