package org.example.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.http.UrlPath;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;


import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import static org.example.stepDefs.Hooks.driver;

public class P03_homePage {

    public P03_homePage() {
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "customerCurrency")
    public WebElement customerCurrency;

    public void changeCurrency() {
        Select selectCurrency = new Select(customerCurrency);
        selectCurrency.selectByVisibleText("Euro");
    }

    public void checkSymbol() {
        WebElement element = driver.findElement(By.tagName("div"));
        List<WebElement> elements = element.findElements(By.tagName("€"));
        for (WebElement e : elements) {
            String temp = e.getText();
            String expected = "€";
            Assert.assertTrue(temp.contains(expected));
        }
    }

    @FindBy(id="small-searchterms")
    public WebElement search;

    String Result = null;
    public void searchByName(String name)
    {
        name.toLowerCase();
        search.sendKeys(name);
        Result = name;
    }

    public void searchBySku(String sku)
    {
        sku.toLowerCase();
        search.sendKeys(sku);
        Result = sku;
    }

    @FindBy(xpath = "/html/body/div[6]/div[1]/div[2]/div[2]/form/button")
    public WebElement searchBtn;

    List<String> list = new ArrayList<String>();
    public void results()
    {
        SoftAssert soft = new SoftAssert();
        soft.assertEquals(driver.getCurrentUrl(),"https://demo.nopcommerce.com/search?q="+Result,"Search results displayed");
        WebElement element = driver.findElement(By.tagName("div"));
        List<WebElement> elements = element.findElements(By.tagName(Result));
        for (WebElement e : elements) {
            String temp = e.getText().toLowerCase();
            String expected = Result.toLowerCase();
            soft.assertTrue(temp.contains(expected));
            list.add(Result);
        }
        soft.assertAll();
    }

    public int noResult()
    {
        System.out.println(list);
        return list.size();
    }

    public void skuResults()
    {
        WebElement element = driver.findElement(By.tagName("div"));
        List<WebElement> elements = element.findElements(By.tagName(Result));
        for (WebElement e : elements) {
            String temp = e.getText();
            String expected = Result;
            Assert.assertTrue(temp.contains(expected));
        }
        Result=null;
    }

    @FindBy(linkText = "Computers")
    WebElement computersLink;

    @FindBy(linkText = "Desktops")
    WebElement desktopsLink;


    public void MouseHover() throws InterruptedException {
        Actions action = new Actions(driver);
        action.moveToElement(computersLink).build().perform();
        Thread.sleep(2000);
    }

    public void SelectDesktop() throws InterruptedException {
        MouseHover();
        Actions action = new Actions(driver);
        action.moveToElement(desktopsLink);
        action.click().build().perform();
    }

    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div[3]/div/div[1]/h1")
    WebElement pageTitle;

    public void displayedSuccessfully()
    {
        String expectedTitle = "Desktops".toLowerCase().trim();
        String actualTitle = pageTitle.getText().toLowerCase().trim();
        Assert.assertTrue(actualTitle.contains(expectedTitle));
    }

    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div/div/div/div[1]/div[1]/a[2]")
    WebElement firstSlider;

    public void chooseFirstSlider()
    {
        firstSlider.click();
    }

    public void firstSliderDisplayed()
    {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.urlToBe("https://demo.nopcommerce.com/nokia-lumia-1020"));
    }

    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div/div/div/div[1]/div[1]/a[2]")
    WebElement secondSlider;

    public void chooseSecondSlider()
    {
        secondSlider.click();
    }

    public void secondSliderDisplayed()
    {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.urlToBe("https://demo.nopcommerce.com/iphone-6"));
    }

    @FindBy(xpath = "/html/body/div[6]/div[4]/div[1]/div[4]/div[1]/ul/li[1]/a")
    public WebElement facebook;

    public void facebookDisplayed() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(7));
        wait.until(ExpectedConditions.numberOfWindowsToBe(2));
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        System.out.println(tabs.size());
        driver.switchTo().window(tabs.get(1));
        Assert.assertEquals(driver.getCurrentUrl(),"https://www.facebook.com/nopCommerce");
        Thread.sleep(2000);
        driver.close();
        driver.switchTo().window(tabs.get(0));
    }

    @FindBy(xpath = "/html/body/div[6]/div[4]/div[1]/div[4]/div[1]/ul/li[2]/a")
    public WebElement twitter;

    public void twitterDisplayed() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(7));
        wait.until(ExpectedConditions.numberOfWindowsToBe(2));
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        System.out.println(tabs.size());
        driver.switchTo().window(tabs.get(1));
        Assert.assertEquals(driver.getCurrentUrl(),"https://twitter.com/nopCommerce");
        Thread.sleep(2000);
        driver.close();
        driver.switchTo().window(tabs.get(0));
    }

    @FindBy(xpath = "/html/body/div[6]/div[4]/div[1]/div[4]/div[1]/ul/li[3]/a")
    WebElement rss;

    public void rssNewTab()
    {
        Actions action = new Actions(driver);
        action.keyDown(Keys.CONTROL).moveToElement(rss).click().perform();
    }

    public void rssDisplayed() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(7));
        wait.until(ExpectedConditions.numberOfWindowsToBe(2));
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        System.out.println(tabs.size());
        driver.switchTo().window(tabs.get(1));
        Assert.assertEquals(driver.getCurrentUrl(),"https://demo.nopcommerce.com/new-online-store-is-open");
        Thread.sleep(2000);
        driver.close();
        driver.switchTo().window(tabs.get(0));
    }

    @FindBy(xpath = "/html/body/div[6]/div[4]/div[1]/div[4]/div[1]/ul/li[4]/a")
    public WebElement youtube;

    public void youtubeDisplayed() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(7));
        wait.until(ExpectedConditions.numberOfWindowsToBe(2));
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        System.out.println(tabs.size());
        driver.switchTo().window(tabs.get(1));
        Assert.assertEquals(driver.getCurrentUrl(),"https://www.youtube.com/user/nopCommerce");
        Thread.sleep(2000);
        driver.close();
        driver.switchTo().window(tabs.get(0));
    }

    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div/div/div/div[4]/div[2]/div[3]/div/div[2]/div[3]/div[2]/button[3]")
    public WebElement heartBtn;

    @FindBy(className = "wishlist-label")
    public WebElement wishlistBtn;

    public void MsgDisplayed()
    {
        SoftAssert soft = new SoftAssert();
        String expectedMsg = "The product has been added to your wishlist";
        String actualMsg = driver.findElement(By.xpath("//p[@class = \"content\"]")).getText();
        soft.assertTrue(actualMsg.contains(expectedMsg));

        String expectedColor = "4bb07a";
        String displayedColor = driver.findElement(By.xpath("//div[@class = \"bar-notification success\"]")).getCssValue("background-color");
        String actualColor = Color.fromString(displayedColor).asHex();
        soft.assertTrue(actualColor.contains(expectedColor));
        soft.assertAll();
    }

    public void waitMsgDisappears()
    {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
        wait.until(ExpectedConditions.visibilityOf(wishlistBtn));
        wait.until(ExpectedConditions.elementToBeClickable(wishlistBtn));
    }

    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/form/div[1]/table/tbody/tr/td[6]/input")
    WebElement Qty;

    public boolean checkQty()
    {
        //System.out.println(Qty.getAttribute("value"));
        int quantity = Integer.parseInt(Qty.getAttribute("value"));
        System.out.println(quantity);
        if(quantity>0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}
