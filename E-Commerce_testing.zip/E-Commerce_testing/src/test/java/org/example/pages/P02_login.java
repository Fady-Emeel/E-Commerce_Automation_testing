package org.example.pages;

import org.example.stepDefs.Hooks;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.support.Color;
import static org.example.stepDefs.Hooks.driver;

public class P02_login {

    public P02_login()
    {
        PageFactory.initElements(driver,this);
    }

    @FindBy(className = "ico-login")
    public WebElement login;


    @FindBy(id = "Email")
    WebElement email;

    @FindBy(id="Password")
    WebElement password;

    public void loginSteps(String Email, String Password)
    {
        email.clear();
        email.sendKeys(Email);

        password.clear();
        password.sendKeys(Password);
    }

    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")
    public WebElement loginBtn;

    @FindBy(className="ico-account")
    WebElement myAccount;

    public void loginSuccessfully()
    {
        SoftAssert soft = new SoftAssert();
        soft.assertEquals(driver.getCurrentUrl(),"https://demo.nopcommerce.com/","Home page displayed");
        boolean isDisplayed = myAccount.isDisplayed();
        soft.assertTrue(isDisplayed,"My Account is displayed");
        soft.assertAll();
    }

    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[1]")
    WebElement errorMsg;

    public void wrongLogin()
    {
        SoftAssert soft = new SoftAssert();
        String expectedMsg = "Login was unsuccessful.";
        String actualMsg = errorMsg.getText();
        soft.assertEquals(actualMsg.contains(expectedMsg),true,"Text");

        String expectedColor = "#e4434b";
        String displayedColor = errorMsg.getCssValue("color");
        String actualColor = Color.fromString(displayedColor).asHex();
        soft.assertEquals(actualColor.contains(expectedColor),true,"Color");
        soft.assertAll();
    }

}
