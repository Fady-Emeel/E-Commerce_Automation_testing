package org.example.stepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;

public class D05_hoverCategoriesStepDef {

    P03_homePage home = new P03_homePage();

    @Given("user hover over Computers")
    public void mouseHover() throws InterruptedException {
        home.MouseHover();
    }

    @When("user select Desktops")
    public void selectDesktop() throws InterruptedException {
        home.SelectDesktop();
    }

    @Then("Desktops is displayed successfully")
    public void displayedSuccessfully()
    {
        home.displayedSuccessfully();
    }
}
