package org.example.stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P01_register;


public class D01_registerStepDef {

    P01_register register = new P01_register();

    @Given("user go to register page")
    public void registerPage()
    {
        register.registerLink.click();
    }

    @When("user select gender type")
    public void selectGender()
    {
        register.maleBtn.click();
    }

    @When("^user enter first name \"(.*)\" and last name \"(.*)\"$")
    public void enterName(String FirstName, String LastName)
    {
        register.registerSteps(FirstName,LastName);
    }

    @When("user enter date of birth")
    public void enterDate() throws InterruptedException {
        String Day = "20";
        String Month ="11";
        String Year = "2001";
        register.dateOfBirth(Day,Month,Year);
    }

    @When("^user enter email \"(.*)\" field$")
    public void enterEmail(String email)
    {
        register.enterEmail(email);
    }

    @When("^user fills Password fields \"(.*)\" \"(.*)\"$")
    public void enterPassword(String password,String confirmPassword)
    {
        register.enterPassword(password,confirmPassword);
    }

    @And("user clicks on register button")
    public void clickRegister()
    {
        register.registerBtn.click();
    }

    @Then("success message is displayed")
    public void successMsgDisplayed()
    {
        register.successMsgDisplay();
    }



}
