package org.example.stepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.example.pages.P03_homePage;

public class D06_homeSlidersStepDef {

    P03_homePage home = new P03_homePage();

    @Given("user click on first slider")
    public void chooseFirstSlider()
    {
        home.chooseFirstSlider();
    }
    @Then("first slider navigates to another page")
    public void firstSliderDisplayed()
    {
        home.firstSliderDisplayed();
    }

    @Given("user click on second slider")
    public void chooseSecondSlider()
    {
        home.chooseSecondSlider();
    }
    @Then("second slider navigates to another page")
    public void SecondSliderDisplayed()
    {
        home.secondSliderDisplayed();
    }
}
