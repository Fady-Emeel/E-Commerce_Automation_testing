package org.example.stepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.example.pages.P03_homePage;

public class D07_followUsStepDef {

    P03_homePage home = new P03_homePage();

    @Given("user click on facebook link")
    public void chooseFacebook() throws InterruptedException {
        home.facebook.click();
        Thread.sleep(2000);
    }

    @Then("facebook is opened in new window")
    public void facebookDisplayed() throws InterruptedException {
        home.facebookDisplayed();
    }

    @Given("user click on twitter link")
    public void chooseTwitter() throws InterruptedException {
        home.twitter.click();
        Thread.sleep(2000);
    }

    @Then("twitter is opened in new window")
    public void twitterDisplayed() throws InterruptedException {
        home.twitterDisplayed();
    }

    @Given("user click on rss link")
    public void chooseRSS() throws InterruptedException {
        home.rssNewTab();
        Thread.sleep(2000);
    }

    @Then("rss is opened in new window")
    public void rssDisplayed() throws InterruptedException {
        home.rssDisplayed();
    }

    @Given("user click on youtube link")
    public void chooseYoutube() throws InterruptedException {
        home.youtube.click();
        Thread.sleep(2000);
    }

    @Then("youtube is opened in new window")
    public void youtubeDisplayed() throws InterruptedException {
        home.youtubeDisplayed();
    }
}
