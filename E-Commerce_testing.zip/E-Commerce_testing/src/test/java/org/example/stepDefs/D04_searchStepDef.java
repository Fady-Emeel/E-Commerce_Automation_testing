package org.example.stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;

public class D04_searchStepDef {

    P03_homePage home = new P03_homePage();

    @Given("user go to search box")
    public void search()
    {
        home.search.click();
    }

    @When("user type product name")
    public void typeName()
    {
        home.searchByName("book");
    }

    @When("^user type product \"(.*)\"$")
    public void typeSku(String sku)
    {
        home.searchBySku(sku);
    }

    @And("user press search")
    public void searchBtn()
    {
        home.searchBtn.click();
    }

    @Then("user could find the product")
    public void results()
    {
        home.results();
    }

    @Then("user could find the sku product")
    public void skuResults()
    {
        home.skuResults();
    }

    @And("user could see number of search result")
    public void noResults()
    {
        home.noResult();
    }

}
