package org.example.stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;

public class D08_WishlistStepDef {

    P03_homePage home = new P03_homePage();

    @Given("user press ❤ button")
    public void pressHeartBtn() {
        home.heartBtn.click();
    }

    @Then("success message appears")
    public void msgAppears()
    {
        home.MsgDisplayed();
    }

    @And("user wait till success message disappears")
    public void waitMsgDisappear()
    {
        home.waitMsgDisappears();
    }

    @When("user open wishlist")
    public void openWishlist()
    {
        home.wishlistBtn.click();
    }

    @Then("user check Qty")
    public void checkQty()
    {
        home.checkQty();
    }

}
