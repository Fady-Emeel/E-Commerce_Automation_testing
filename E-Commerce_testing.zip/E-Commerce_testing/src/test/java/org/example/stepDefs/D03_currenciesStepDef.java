package org.example.stepDefs;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P03_homePage;

public class D03_currenciesStepDef {

    P03_homePage home = new P03_homePage();

    @Given("user go to choose currency")
    public void CustomerCurrency()
    {
        home.customerCurrency.click();
    }

    @When("user change currency to euro")
    public void changeCurrency()
    {
        home.changeCurrency();
    }

    @Then("\"€\" symbol is displayed")
    public void checkSymbol()
    {
        home.checkSymbol();
    }
}
