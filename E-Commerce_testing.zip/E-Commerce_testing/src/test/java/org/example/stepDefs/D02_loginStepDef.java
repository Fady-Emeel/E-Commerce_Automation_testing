package org.example.stepDefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.pages.P02_login;

public class D02_loginStepDef {

    P02_login login = new P02_login();

    @Given("user go to login page")
    public void loginPage()
    {
        login.login.click();
    }

    @When("^user login with \"valid\" \"(.*)\" and \"(.*)\"$")
    public void validLogin(String email, String password)
    {
        login.loginSteps(email,password);
    }

    @And("user press on login button")
    public void LoginBtn()
    {
        login.loginBtn.click();
    }

    @Then("user login to the system successfully")
    public void loginSuccessfully()
    {
        login.loginSuccessfully();
    }

    @When("^user login with \"invalid\" \"(.*)\" and \"(.*)\"$")
    public void invalidLogin(String email, String password)
    {
        login.loginSteps(email,password);
    }

    @Then("user could not login to the system")
    public void wrongLogin()
    {
        login.wrongLogin();
    }
}
